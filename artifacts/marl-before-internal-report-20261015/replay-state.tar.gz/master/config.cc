#include "NetSim.h"
#include "ns3/system-path.h"
#include <algorithm>
#include <filesystem>
#include <cmath>
#include <unistd.h>

NS_LOG_COMPONENT_DEFINE("researchMain");

namespace {

// master_log だけを残すため、FlowMonitorの補助出力は止める。
constexpr bool kEnableFlowOutputLogs = false;

struct BaselineSetting
{
    int baseStations = 0;
    int terminals = 0;
    std::vector<int> capacities;
    std::vector<double> initialRtt;
    int numCycles = 10;
    double cycleTimeSec = 3.5;
    double warmupBeforeCycleSec = 0.0;
    double monitorStartSec = 1.1;
    double monitorStopSec = 4.0;
    double browserFirstBurstSec = 1.2;
    double browserSecondBurstSec = 2.1;
    double browserBurstIntervalSec = 1.0;
    int browserNumRequests = 5;
    int browserRequestSize = 512000;
    double cycleEndMarginSec = 0.5;
    int handoverGraceCycles = 2;
    double browserPostHandoverDelaySec = 0.0;
    double terminalTpStopSec = 4.0;
    uint32_t rngSeed = 1;
};

std::string Trim(const std::string& str)
{
    const auto begin = str.find_first_not_of(" \t\n\r");
    if (begin == std::string::npos)
    {
        return "";
    }
    const auto end = str.find_last_not_of(" \t\n\r");
    return str.substr(begin, end - begin + 1);
}

bool ExtractJsonInt(const std::string& content, const std::string& key, int& out)
{
    std::regex re("\\\"" + key + "\\\"\\s*:\\s*(\\d+)");
    std::smatch match;
    if (std::regex_search(content, match, re))
    {
        out = std::stoi(match[1]);
        return true;
    }
    return false;
}

bool ExtractJsonDouble(const std::string& content, const std::string& key, double& out)
{
    std::regex re("\\\"" + key + "\\\"\\s*:\\s*([0-9]*\\.?[0-9]+)");
    std::smatch match;
    if (std::regex_search(content, match, re))
    {
        out = std::stod(match[1]);
        return true;
    }
    return false;
}

bool ExtractJsonArrayInt(const std::string& content, const std::string& key, std::vector<int>& out)
{
    std::regex re("\\\"" + key + "\\\"\\s*:\\s*\\[([^\\]]*)\\]");
    std::smatch match;
    if (!std::regex_search(content, match, re))
    {
        return false;
    }
    std::stringstream ss(match[1].str());
    std::string item;
    out.clear();
    while (std::getline(ss, item, ','))
    {
        item = Trim(item);
        if (!item.empty())
        {
            out.push_back(std::stoi(item));
        }
    }
    return !out.empty();
}

bool ExtractJsonArrayDouble(const std::string& content, const std::string& key, std::vector<double>& out)
{
    std::regex re("\\\"" + key + "\\\"\\s*:\\s*\\[([^\\]]*)\\]");
    std::smatch match;
    if (!std::regex_search(content, match, re))
    {
        return false;
    }
    std::stringstream ss(match[1].str());
    std::string item;
    out.clear();
    while (std::getline(ss, item, ','))
    {
        item = Trim(item);
        if (!item.empty())
        {
            out.push_back(std::stod(item));
        }
    }
    return !out.empty();
}

bool LoadBaselineSetting(const std::string& path, BaselineSetting& setting)
{
    std::ifstream ifs(path);
    if (ifs.fail())
    {
        std::cerr << "Failed to open setting config: " << path << std::endl;
        return false;
    }
    std::string content((std::istreambuf_iterator<char>(ifs)), std::istreambuf_iterator<char>());
    if (!ExtractJsonInt(content, "baseStations", setting.baseStations))
    {
        std::cerr << "Failed to parse baseStations from setting config" << std::endl;
        return false;
    }
    if (!ExtractJsonInt(content, "terminals", setting.terminals))
    {
        std::cerr << "Failed to parse terminals from setting config" << std::endl;
        return false;
    }
    if (!ExtractJsonArrayInt(content, "capacities", setting.capacities))
    {
        setting.capacities.assign(setting.baseStations, 100);
    }
    if (!ExtractJsonArrayDouble(content, "initialRttHungarian", setting.initialRtt))
    {
        setting.initialRtt.assign(setting.baseStations, 50.0);
    }
    if (setting.capacities.size() < static_cast<size_t>(setting.baseStations))
    {
        setting.capacities.resize(setting.baseStations, 100);
    }
    if (setting.initialRtt.size() < static_cast<size_t>(setting.baseStations))
    {
        setting.initialRtt.resize(setting.baseStations, 50.0);
    }
    // オプションパラメータの読み込み（JSONになければ構造体のデフォルト値を維持）
    {
        int tmp = 0;
        double dtmp = 0.0;
        if (ExtractJsonInt(content, "numCycles", tmp)) { setting.numCycles = tmp; }
        if (ExtractJsonDouble(content, "cycleTimeSec", dtmp)) { setting.cycleTimeSec = dtmp; }
        if (ExtractJsonDouble(content, "warmupBeforeCycleSec", dtmp)) { setting.warmupBeforeCycleSec = dtmp; }
        if (ExtractJsonDouble(content, "monitorStartSec", dtmp)) { setting.monitorStartSec = dtmp; }
        if (ExtractJsonDouble(content, "monitorStopSec", dtmp)) { setting.monitorStopSec = dtmp; }
        if (ExtractJsonDouble(content, "browserFirstBurstSec", dtmp)) { setting.browserFirstBurstSec = dtmp; }
        if (ExtractJsonDouble(content, "browserSecondBurstSec", dtmp)) { setting.browserSecondBurstSec = dtmp; }
        if (ExtractJsonDouble(content, "browserBurstIntervalSec", dtmp)) { setting.browserBurstIntervalSec = dtmp; }
        if (ExtractJsonInt(content, "browserNumRequests", tmp)) { setting.browserNumRequests = tmp; }
        if (ExtractJsonInt(content, "browserRequestSize", tmp)) { setting.browserRequestSize = tmp; }
        if (ExtractJsonDouble(content, "cycleEndMarginSec", dtmp)) { setting.cycleEndMarginSec = dtmp; }
        if (ExtractJsonInt(content, "handoverGraceCycles", tmp)) { setting.handoverGraceCycles = tmp; }
        if (ExtractJsonDouble(content, "browserPostHandoverDelaySec", dtmp)) { setting.browserPostHandoverDelaySec = dtmp; }
        if (ExtractJsonInt(content, "rngSeed", tmp)) { setting.rngSeed = static_cast<uint32_t>(tmp); }
    }
    // 制約バリデーション
    if (setting.warmupBeforeCycleSec < 0.0)
    {
        std::cerr << "[WARN] warmupBeforeCycleSec=" << setting.warmupBeforeCycleSec
                  << " must be >= 0.0. Resetting to 0.0." << std::endl;
        setting.warmupBeforeCycleSec = 0.0;
    }
    if (setting.monitorStartSec <= 1.0)
    {
        std::cerr << "[WARN] monitorStartSec=" << setting.monitorStartSec
                  << " must be > 1.0. Resetting to 1.1." << std::endl;
        setting.monitorStartSec = 1.1;
    }
    if (setting.monitorStopSec <= setting.monitorStartSec)
    {
        std::cerr << "[WARN] monitorStopSec=" << setting.monitorStopSec
                  << " must be > monitorStartSec. Resetting to 4.0." << std::endl;
        setting.monitorStopSec = 4.0;
    }
    const double maxStop = setting.cycleTimeSec + setting.monitorStartSec;
    if (setting.monitorStopSec >= maxStop)
    {
        std::cerr << "[WARN] monitorStopSec=" << setting.monitorStopSec
                  << " must be < cycleDuration+monitorStart (" << maxStop << "). Resetting to 4.0." << std::endl;
        setting.monitorStopSec = 4.0;
    }
    if (setting.browserFirstBurstSec <= setting.monitorStartSec)
    {
        std::cerr << "[WARN] browserFirstBurstSec=" << setting.browserFirstBurstSec
                  << " must be > monitorStartSec. Resetting to monitorStart+0.1." << std::endl;
        setting.browserFirstBurstSec = setting.monitorStartSec + 0.1;
    }

    const int browserSecondBurstRequests = std::max(0, setting.browserNumRequests - 1);
    const double lastBrowserBurstSec =
        browserSecondBurstRequests > 0
            ? setting.browserSecondBurstSec +
                  setting.browserBurstIntervalSec * static_cast<double>(browserSecondBurstRequests - 1)
            : setting.browserFirstBurstSec;
    const double browserCompletionGuardSec =
        std::max(1.0, setting.browserBurstIntervalSec * 4.0 + 0.7);
    const double terminalTpStopSec =
        std::max(setting.monitorStopSec, lastBrowserBurstSec + browserCompletionGuardSec);
    setting.terminalTpStopSec = terminalTpStopSec;

    // Ending() が次サイクルに食い込まないことを保証
    if (terminalTpStopSec + setting.cycleEndMarginSec >= setting.cycleTimeSec)
    {
        std::cerr << "[ERROR] terminalTpStopSec(" << terminalTpStopSec
                  << ") + cycleEndMarginSec(" << setting.cycleEndMarginSec
                  << ") must be < cycleTimeSec(" << setting.cycleTimeSec
                  << "). Increase cycleTimeSec so browser bursts can complete before the next cycle."
                  << std::endl;
        NS_FATAL_ERROR("Invalid timing: cycleEndMargin overflow");
    }
    // TP計測ウィンドウ内にブラウザトラフィックが発生することを保証
    if (setting.browserFirstBurstSec >= setting.monitorStopSec)
    {
        std::cerr << "[ERROR] browserFirstBurstSec(" << setting.browserFirstBurstSec
                  << ") must be < monitorStopSec(" << setting.monitorStopSec
                  << "). No browser traffic would be captured in the TP window." << std::endl;
        NS_FATAL_ERROR("Invalid timing: browserFirstBurst outside TP window");
    }
    if (setting.browserSecondBurstSec >= setting.monitorStopSec)
    {
        std::cerr << "[ERROR] browserSecondBurstSec(" << setting.browserSecondBurstSec
                  << ") must be < monitorStopSec(" << setting.monitorStopSec
                  << "). Second browser burst would not be captured in the TP window." << std::endl;
        NS_FATAL_ERROR("Invalid timing: browserSecondBurst outside TP window");
    }
    return true;
}

} // namespace

namespace ns3 {

NetSim::NetSim()
{
    termNum = 1;
    APnum = 1;
    m_mob = 1;
    m_assignmentMethod = "random";
    m_dqnActionCsvPath = "episodes/dqn/actions/actions_dqn_seed1.csv";
    m_drlServerHost = "127.0.0.1";
    m_drlServerPort = 50051;
    m_drlTimeoutMs = 200;
    m_maxSwitches = 8;
    m_kScheduleType = "fixed";
    m_kMin = 1;
    m_kDecayRate = 1;
    m_rewardSwitchPenaltyAlpha = 0.001;
    m_rewardDegradedPenaltyBeta = 0.001;
    m_onlineDqnSafetyThreshold = 0.0;
    m_centralizedDqnBootstrapCycles = 0;
    m_centralizedDqnStateSchema = "v1";
    m_rngSeed = 1;
    m_outputDir = OUTPUT_ROOT_DIR;
    server_udpVoice = nullptr;
    server_udpVideo = nullptr;
    server_rtt = nullptr;
    server_onlineGame = nullptr;
    server_browser = nullptr;
    remote_host = nullptr;
    cerNode = nullptr;
    m_remoteHostAddress = Ipv4Address::GetZero();
    m_cycleCount = 10;
    m_cycleDuration = Seconds(3.5);
    m_simulationDuration = m_cycleDuration * m_cycleCount;
    m_browserRequestInterval = Seconds(1.0);
    m_browserRequestCount = 5;
    m_monitorStartOffset  = Seconds(1.1);
    m_warmupBeforeCycle = Seconds(0.0);
    m_cycleStartOffset = Seconds(0.0);
    m_monitorStopOffset   = Seconds(4.0);
    m_terminalTpStopOffset = Seconds(4.0);
    m_browserFirstRequest = Seconds(1.2);
    m_browserBatchBStart  = Seconds(2.1);
    m_browserRequestBytes = 500u * 1024u;
    m_cycleEndGuard              = Seconds(0.5);
    m_browserPostHandoverDelay   = Seconds(0.0);
    m_terminalTpWindowStart = Seconds(0.0);

    // Ensure root OUTPUT directory exists.  The terminal-count subdirectory is
    // selected after setting.json is loaded in Init().
    SystemPath::MakeDirectories(OUTPUT_ROOT_DIR);
}

NetSim::~NetSim(){
}

void NetSim::Init(int argc, char *argv[]){
    NS_LOG_FUNCTION(this);

    uint32_t cliRngSeed = 0;
    std::string appTypesPath;
    std::string outputRoot = OUTPUT_ROOT_DIR;
    bool perfTiming = false;
    bool perfDetailed = false;
    uint64_t perfWifiSampleEvery = 1024;
    std::string perfOutputDir = "results/perf";
    CommandLine cmd;
    cmd.AddValue("capacityEventsPath", "CSV capacity schedule; exclusive with legacy capacity experiments", m_capacityEventsPath);
    cmd.AddValue("ap0CapacityVariation", "Vary PGW-CER backhaul in both directions (default off)", m_ap0CapacityVariation);
    cmd.AddValue("ap0CapacityTrace", "Save AP0 capacity metadata and queue samples, also for constant baseline", m_ap0CapacityTrace);
    cmd.AddValue("ap0LowRate", "AP0 reduced capacity", m_ap0LowRate);
    cmd.AddValue("ap0DropCycle", "1-based cycle at whose start AP0 capacity drops", m_ap0DropCycle);
    cmd.AddValue("ap0RecoveryCycle", "1-based cycle at whose start AP0 capacity recovers", m_ap0RecoveryCycle);
    cmd.AddValue("ap0SampleSec", "AP0 queue sampling interval in seconds", m_ap0SampleSec);
    cmd.AddValue("ap2CapacityVariation", "Vary Wi-Fi AP2 backhaul in both directions (default off)", m_ap2CapacityVariation);
    cmd.AddValue("ap2CapacityTrace", "Save AP2 capacity metadata and queue samples, also for constant baseline", m_ap2CapacityTrace);
    cmd.AddValue("ap2LowRate", "AP2 reduced capacity", m_ap2LowRate);
    cmd.AddValue("ap2DropCycle", "1-based cycle at whose start AP2 capacity drops", m_ap2DropCycle);
    cmd.AddValue("ap2RecoveryCycle", "1-based cycle at whose start AP2 capacity recovers", m_ap2RecoveryCycle);
    cmd.AddValue("ap2SampleSec", "AP2 queue sampling interval in seconds", m_ap2SampleSec);
    cmd.AddValue("ap1CapacityVariation", "Vary Wi-Fi AP1 backhaul in both directions (default off)", m_ap1CapacityVariation);
    cmd.AddValue("ap1CapacityTrace", "Save AP1 capacity metadata and queue samples, also for constant baseline", m_ap1CapacityTrace);
    cmd.AddValue("ap1LowRate", "AP1 reduced capacity", m_ap1LowRate);
    cmd.AddValue("ap1DropCycle", "1-based cycle at whose start AP1 capacity drops", m_ap1DropCycle);
    cmd.AddValue("ap1RecoveryCycle", "1-based cycle at whose start AP1 capacity recovers", m_ap1RecoveryCycle);
    cmd.AddValue("ap1SampleSec", "AP1 queue sampling interval in seconds", m_ap1SampleSec);
    cmd.AddValue("marlProbeCount", "MARL probes per AP/window", m_marlProbeCount);
    cmd.AddValue("marlProbeInterval", "MARL probe interval seconds", m_marlProbeInterval);
    cmd.AddValue("marlProbeTimeout", "MARL strict response deadline seconds", m_marlProbeTimeout);
    cmd.AddValue("marlRttTrace", "Passive ICMP path/MAC trace for MARL diagnosis", m_marlRttTrace);
    cmd.AddValue("marlReportConnTimeout", "MARL report TCP connection retransmission timeout seconds", m_marlReportConnTimeout);
    cmd.AddValue("pgwCerRate", "PGW-CER capacity; other link parameters unchanged", m_pgwCerRate);
    cmd.AddValue("ap1BackhaulRate", "Wi-Fi AP1 initial backhaul capacity", m_ap1BackhaulRate);
    cmd.AddValue("ap2BackhaulRate", "Wi-Fi AP2 initial backhaul capacity", m_ap2BackhaulRate);
    cmd.AddValue("appTypesPath", "Optional whitespace-separated app IDs (1..4), one per UE", appTypesPath);
    cmd.AddValue("outputRoot", "Output root for isolated comparison experiments", outputRoot);
    m_queueSettingPath = std::string(INPUT_DIR) + "setting.json";
    cmd.AddValue("settingPath", "Experiment JSON (default: data/setting.json)", m_queueSettingPath);
    cmd.AddValue("queueDiagnostics", "Write PGW-CER and NR UM buffer samples (default off)", m_queueDiagnostics);
    cmd.AddValue("queueSampleSec", "Queue diagnostic sampling interval in simulation seconds", m_queueSampleSec);
    cmd.AddValue("perfTiming", "Enable wall-clock timing without changing simulation events", perfTiming);
    cmd.AddValue("perfDetailed", "Also time NR/Wi-Fi/FlowMonitor internals (implies perfTiming)", perfDetailed);
    cmd.AddValue("perfWifiSampleEvery", "Sample Wi-Fi subphases once per N receptions (positive)", perfWifiSampleEvery);
    cmd.AddValue("perfOutputDir", "Parent directory for unique timing run directories", perfOutputDir);
    cmd.AddValue("method", "Assignment method: no_switch, random, all5g, rulebase, greedy, multi_greedy, multi_offload, logistic, dqn, multi_dqn, online_dqn, centralized_dqn, reactive_dqn, marl_ppo", m_assignmentMethod);
    cmd.AddValue("rngSeed",
                 "Override rngSeed from data/setting.json when non-zero. This avoids editing setting.json during parallel runs.",
                 cliRngSeed);
    cmd.AddValue("dqnActionCsv",
                 "DQN/Multi-DQN action CSV path used when --method=dqn or --method=multi_dqn",
                 m_dqnActionCsvPath);
    cmd.AddValue("drlServerHost",
                 "External learner TCP server host (including marl_ppo)",
                 m_drlServerHost);
    cmd.AddValue("drlServerPort",
                 "External learner TCP server port (including marl_ppo)",
                 m_drlServerPort);
    cmd.AddValue("drlTimeoutMs",
                 "Online DQN TCP JSON request timeout in milliseconds",
                 m_drlTimeoutMs);
    cmd.AddValue("maxSwitches",
                 "Maximum number of UE switches per cycle for multi_greedy, multi_offload, multi_dqn, and online_dqn",
                 m_maxSwitches);
    cmd.AddValue("kScheduleType",
                 "Switch budget schedule: fixed or linear_decay. fixed uses --maxSwitches every cycle; linear_decay uses max(maxSwitches - kDecayRate*(cycle-1), kMin)",
                 m_kScheduleType);
    cmd.AddValue("kMin",
                 "Minimum switch budget used when --kScheduleType=linear_decay",
                 m_kMin);
    cmd.AddValue("kDecayRate",
                 "Per-cycle switch budget decay used when --kScheduleType=linear_decay",
                 m_kDecayRate);
    cmd.AddValue("rewardSwitchPenaltyAlpha",
                 "Online DQN reward penalty coefficient for switch_count",
                 m_rewardSwitchPenaltyAlpha);
    cmd.AddValue("rewardDegradedPenaltyBeta",
                 "Online DQN reward penalty coefficient for num_degraded_users",
                 m_rewardDegradedPenaltyBeta);
    cmd.AddValue("onlineDqnSafetyThreshold",
                 "Skip an online_dqn handover when estimated H delta of the selected BS is <= this threshold",
                 m_onlineDqnSafetyThreshold);
    cmd.AddValue("centralizedDqnBootstrapCycles",
                 "Number of initial cycles controlled by logistic before centralized_dqn starts. 0 disables bootstrap.",
                 m_centralizedDqnBootstrapCycles);
    cmd.AddValue("centralizedDqnStateSchema",
                 "Centralized DQN state schema: v1 or v2_onehot.",
                 m_centralizedDqnStateSchema);
    cmd.AddValue("mob", "1 is constant, 2 is randomwalk", m_mob);
    cmd.Parse(argc, argv);
    NS_ABORT_MSG_IF(DataRate(m_pgwCerRate).GetBitRate() == 0, "pgwCerRate must be positive");
    NS_ABORT_MSG_IF(DataRate(m_ap1BackhaulRate).GetBitRate() == 0, "ap1BackhaulRate must be positive");
    NS_ABORT_MSG_IF(DataRate(m_ap2BackhaulRate).GetBitRate() == 0, "ap2BackhaulRate must be positive");
    NS_ABORT_MSG_IF(!std::isfinite(m_queueSampleSec) || m_queueSampleSec <= 0 ||
                        Seconds(m_queueSampleSec).IsZero(), "queueSampleSec must be positive and representable");
    for (int i = 0; i < argc; ++i)
    {
        m_queueArgs += "argv[" + std::to_string(i) + "]=" + argv[i] + "\n";
    }

    if (m_assignmentMethod != "no_switch" &&
        m_assignmentMethod != "random" && m_assignmentMethod != "all5g" &&
        m_assignmentMethod != "rulebase" &&
        m_assignmentMethod != "greedy" &&
        m_assignmentMethod != "multi_greedy" &&
        m_assignmentMethod != "multi_offload" &&
        m_assignmentMethod != "logistic" && m_assignmentMethod != "dqn" &&
        m_assignmentMethod != "multi_dqn" &&
        m_assignmentMethod != "reactive_dqn" &&
        m_assignmentMethod != "marl_ppo" &&
        m_assignmentMethod != "online_dqn" &&
        m_assignmentMethod != "centralized_dqn" &&
        m_assignmentMethod != "ml")
    {
        NS_FATAL_ERROR("Unknown assignment method: " << m_assignmentMethod);
    }

    BaselineSetting setting;
    const std::string settingPath = m_queueSettingPath;
    NS_ABORT_MSG_IF(!LoadBaselineSetting(settingPath, setting),
                    "Cannot load experiment settings: " << settingPath);
    m_rngSeed = (cliRngSeed > 0) ? cliRngSeed : setting.rngSeed;
    std::cout << "シード値: " << m_rngSeed
              << " (setting.json/\"rngSeed\"=" << setting.rngSeed;
    if (cliRngSeed > 0)
    {
        std::cout << ", command line override --rngSeed=" << cliRngSeed;
    }
    std::cout << ")" << std::endl;
    APnum = static_cast<uint32_t>(setting.baseStations);
    termNum = static_cast<uint32_t>(setting.terminals);
    m_warmupBeforeCycle = Seconds(setting.warmupBeforeCycleSec);
    // 既存実験との互換性のため、設定値が 0 の場合は従来通り
    // cycle 1 の基準時刻を 0s とする。warm-up を明示した場合のみ、
    // アプリ開始時刻(概ね 1.0s) + warm-up 秒を cycle 1 の基準時刻にする。
    m_cycleStartOffset =
        (setting.warmupBeforeCycleSec > 0.0)
            ? (Seconds(1.0) + m_warmupBeforeCycle)
            : Seconds(0.0);
    std::string outputMethodDir = m_assignmentMethod;
    if (m_assignmentMethod == "multi_greedy" ||
        m_assignmentMethod == "multi_offload" ||
        m_assignmentMethod == "online_dqn" ||
        m_assignmentMethod == "centralized_dqn")
    {
        outputMethodDir += "_K" + std::to_string(m_maxSwitches);
        if (m_assignmentMethod == "online_dqn" && m_kScheduleType != "fixed")
        {
            outputMethodDir += "_" + m_kScheduleType +
                               "_min" + std::to_string(m_kMin) +
                               "_decay" + std::to_string(m_kDecayRate);
        }
        if (m_assignmentMethod == "centralized_dqn" && m_centralizedDqnBootstrapCycles > 0)
        {
            outputMethodDir += "_bootstrap" + std::to_string(m_centralizedDqnBootstrapCycles);
        }
        if (m_assignmentMethod == "centralized_dqn" && m_centralizedDqnStateSchema != "v1")
        {
            outputMethodDir += "_" + m_centralizedDqnStateSchema;
        }
    }
    m_outputDir = (std::filesystem::path(outputRoot) / std::to_string(termNum) /
                   outputMethodDir).string() + "/";
    SystemPath::MakeDirectories(m_outputDir);
    std::cout << "出力ディレクトリ: " << m_outputDir << std::endl;
    std::cout << "warmupBeforeCycleSec: " << setting.warmupBeforeCycleSec
              << " cycleStartOffsetSec: " << m_cycleStartOffset.GetSeconds()
              << std::endl;
    m_cycleCount             = static_cast<uint32_t>(setting.numCycles);
    m_cycleDuration          = Seconds(setting.cycleTimeSec);
    m_monitorStartOffset     = Seconds(setting.monitorStartSec);
    m_monitorStopOffset      = Seconds(setting.monitorStopSec);
    m_terminalTpStopOffset   = Seconds(setting.terminalTpStopSec);
    m_browserFirstRequest    = Seconds(setting.browserFirstBurstSec);
    m_browserBatchBStart     = Seconds(setting.browserSecondBurstSec);
    m_browserRequestInterval = Seconds(setting.browserBurstIntervalSec);
    m_browserRequestCount    = static_cast<uint32_t>(setting.browserNumRequests);
    m_browserRequestBytes    = static_cast<uint32_t>(setting.browserRequestSize);
    m_cycleEndGuard              = Seconds(setting.cycleEndMarginSec);
    m_browserPostHandoverDelay   = Seconds(setting.browserPostHandoverDelaySec);
    RngSeedManager::SetSeed(m_rngSeed);
    RngSeedManager::SetRun(1);

    m_apSelectionInput.baseStations = setting.baseStations;
    m_apSelectionInput.terminals = setting.terminals;
    m_apSelectionInput.capacities = setting.capacities;
    m_apSelectionInput.initialRtt = setting.initialRtt;
    m_apSelectionInput.handoverGraceCycles = static_cast<uint32_t>(setting.handoverGraceCycles);
    m_apSelectionInput.assignmentMethod = m_assignmentMethod;
    m_apSelectionInput.dqnActionCsvPath = m_dqnActionCsvPath;
    m_apSelectionInput.drlServerHost = m_drlServerHost;
    m_apSelectionInput.drlServerPort = m_drlServerPort;
    m_apSelectionInput.drlTimeoutMs = m_drlTimeoutMs;
    m_apSelectionInput.maxSwitches = m_maxSwitches;
    m_apSelectionInput.kScheduleType = m_kScheduleType;
    m_apSelectionInput.kMin = m_kMin;
    m_apSelectionInput.kDecayRate = m_kDecayRate;
    m_apSelectionInput.onlineDqnSafetyThreshold = m_onlineDqnSafetyThreshold;
    m_apSelectionInput.centralizedDqnBootstrapCycles = m_centralizedDqnBootstrapCycles;
    m_apSelectionInput.centralizedDqnStateSchema = m_centralizedDqnStateSchema;
    m_apSelectionInput.rewardSwitchPenaltyAlpha = m_rewardSwitchPenaltyAlpha;
    m_apSelectionInput.rewardDegradedPenaltyBeta = m_rewardDegradedPenaltyBeta;
    m_apSelectionInput.warmupBeforeCycleSec = setting.warmupBeforeCycleSec;
    m_apSelectionInput.cycleStartOffsetSec = m_cycleStartOffset.GetSeconds();
    m_apSelectionInput.rngSeed = m_rngSeed;
    m_apSelectionInput.outputDir = m_outputDir;

    m_termData.clear();
    m_apSelectionInput.useAppli.clear();
    m_apSelectionInput.initialAp.clear();

    Ptr<UniformRandomVariable> apRand = CreateObject<UniformRandomVariable>();
    Ptr<UniformRandomVariable> appRand = CreateObject<UniformRandomVariable>();
    uint32_t apCount = std::max<uint32_t>(APnum, 1);
    std::vector<int> fixedApps;
    if (!appTypesPath.empty())
    {
        std::ifstream input(appTypesPath);
        NS_ABORT_MSG_IF(!input, "Cannot open appTypesPath");
        int app;
        while (input >> app)
        {
            NS_ABORT_MSG_IF(app < 1 || app > 4, "App ID must be 1..4");
            fixedApps.push_back(app);
        }
        NS_ABORT_MSG_IF(!input.eof() || fixedApps.size() != termNum,
                        "appTypesPath must contain exactly terminals integer IDs");
    }
    
    // アプリの出現率の設定
    for (uint32_t i = 0; i < termNum; ++i)
    {
        TermData data;
        const double appDraw = appRand->GetValue(0.0, 1.0);
        if (appDraw < 0.20)
        {
            data.use_appli = 1;
        }
        else if (appDraw < 0.60)
        {
            data.use_appli = 2;
        }
        else if (appDraw < 0.75)
        {
            data.use_appli = 3;
        }
        else
        {
            data.use_appli = 4;
        }
        data.apNo = static_cast<int>(apRand->GetInteger(1, apCount));
        data.x = 0.0;
        data.y = 0.0;
        m_termData.push_back(data);
        if (!fixedApps.empty())
        {
            data.use_appli = fixedApps[i];
            m_termData.back().use_appli = data.use_appli;
        }
        m_apSelectionInput.useAppli.push_back(data.use_appli);
        m_apSelectionInput.initialAp.push_back(data.apNo);
    }
    std::cout << "初期AP番号: [";
    for (size_t i = 0; i < m_apSelectionInput.initialAp.size(); ++i)
    {
        std::cout << m_apSelectionInput.initialAp[i];
        if (i + 1 != m_apSelectionInput.initialAp.size())
        {
            std::cout << ", ";
        }
    }
    std::cout << "]" << std::endl;
    std::cout << "初期アプリ番号: [";
    for (size_t i = 0; i < m_apSelectionInput.useAppli.size(); ++i)
    {
        std::cout << m_apSelectionInput.useAppli[i];
        if (i + 1 != m_apSelectionInput.useAppli.size())
        {
            std::cout << ", ";
        }
    }
    std::cout << "]" << std::endl;
    if (perfTiming || perfDetailed)
    {
        const auto stamp = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();
        const std::string runId = m_assignmentMethod + "_seed" + std::to_string(m_rngSeed) +
            "_" + std::to_string(stamp) + "_pid" + std::to_string(getpid());
        const std::filesystem::path directory = std::filesystem::path(perfOutputDir) / runId;
        ResearchWallProfiler::Get().Start(directory.string(), perfDetailed, perfWifiSampleEvery);
        std::filesystem::copy_file(settingPath, directory / "setting.json");
        std::ofstream metadata(directory / "metadata.txt");
#if defined(NS3_BUILD_PROFILE_OPTIMIZED)
        constexpr const char* buildProfile = "optimized";
#elif defined(NS3_BUILD_PROFILE_DEBUG)
        constexpr const char* buildProfile = "debug";
#else
        constexpr const char* buildProfile = "other";
#endif
        metadata << "run_id=" << runId << "\nseed=" << m_rngSeed
                 << "\nmethod=" << m_assignmentMethod << "\nperf_detailed=" << perfDetailed
                 << "\nprofiler_schema=2\nperf_wifi_sample_every=" << perfWifiSampleEvery
                 << "\nbuild_profile=" << buildProfile
                 << "\nns3_version=3.44\ntiming=inclusive_steady_clock\n"
                 << "threading=single_simulation_thread\n";
        for (int i = 0; i < argc; ++i)
        {
            metadata << "argv[" << i << "]=" << argv[i] << '\n';
        }
        if (!metadata)
        {
            NS_FATAL_ERROR("Cannot write performance metadata");
        }
        std::cout << "[Perf] output=" << directory.string()
                  << " detailed=" << perfDetailed << std::endl;
    }
    m_activeAssignment = m_apSelectionInput.initialAp;

    // 各基地局の接続数を表示
    uint32_t printLimit = std::min<uint32_t>(termNum, static_cast<uint32_t>(m_termData.size()));
    if (APnum > 0 && printLimit > 0)
    {
        std::vector<uint32_t> apCounts(APnum, 0);
        for (uint32_t i = 0; i < printLimit; ++i)
        {
            const auto& data = m_termData[i];
            uint32_t apIndex = (data.apNo > 0) ? static_cast<uint32_t>(data.apNo - 1) : APnum;
            if (apIndex < apCounts.size())
            {
                ++apCounts[apIndex];
            }
        }
        std::cout << "=== Initial terminal counts per AP ===" << std::endl;
        for (uint32_t i = 0; i < apCounts.size(); ++i)
        {
            std::cout << "AP" << (i + 1) << ": " << apCounts[i] << " terminals" << std::endl;
        }
    }

}


void NetSim::Configure(){
    ResearchWallProfiler::Scope perfScope("NetSim::Configure");
    NS_LOG_FUNCTION(this);

    //LogComponentEnable("KamedaAppClient", LOG_LEVEL_INFO);
    //LogComponentEnable("CountRtt", LOG_LEVEL_INFO);
    LogComponentEnable("KamedaAppServer", LOG_LEVEL_INFO);
    //LogComponentEnable("ConnectManager", LOG_LEVEL_INFO);

    //Config::SetDefault ("ns3::WifiRemoteStationManager::RtsCtsThreshold", StringValue ("0"));
    //Config::SetDefault ("ns3::WifiRemoteStationManager::FragmentationThreshold", StringValue ("2200"));

    PacketMetadata::Enable();

    // ARPキャッシュタイムアウトを短縮してハンドオーバー後の再解決を速める（案1）
    Config::SetDefault("ns3::ArpCache::AliveTimeout", TimeValue(Seconds(10)));
    Config::SetDefault("ns3::ArpCache::DeadTimeout", TimeValue(MilliSeconds(50)));
    Config::SetDefault("ns3::ArpCache::WaitReplyTimeout", TimeValue(MilliSeconds(200)));

    // disable fragmentation for frames below 2200 bytes
    //Config::SetDefault ("ns3::WifiRemoteStationManager::FragmentationThreshold", StringValue ("2200"));
    // turn off RTS/CTS for frames below 2200 bytes
    //Config::SetDefault ("ns3::WifiRemoteStationManager::RtsCtsThreshold", StringValue ("2200"));
    // Fix non-unicast data rate to be the same as that of unicast
    //Config::SetDefault ("ns3::WifiRemoteStationManager::NonUnicastMode",
    //                    StringValue ("DsssRate1Mbps"));
}

void NetSim::RunSim(){
    ResearchWallProfiler::Scope perfScope("NetSim::RunSim");

    NS_LOG_FUNCTION(this);

    ConfigureCycleParameters();
    Configure();
    CreateNetworkTopology(); // ノードの生成
    ConfigureDataLinkLayer();
    ConfigureNetworkLayer();
    StartCapacitySchedule();
    StartAp1CapacityExperiment();
    StartAp0CapacityExperiment();
    StartAp2CapacityExperiment();
    // Register actual NetDevice indices, not IPv4 interface indices.
    auto& deviceProfiler = ResearchWallProfiler::Get();
    if (deviceProfiler.Detailed())
    {
        auto registerDevices = [&](const NetDeviceContainer& devices, int ap, const char* rat) {
            for (auto it = devices.Begin(); it != devices.End(); ++it)
            {
                const auto node = (*it)->GetNode();
                std::string role = "base_station";
                for (const auto& terminal : terms)
                {
                    if (terminal == node) { role = "terminal"; break; }
                }
                for (const auto& monitor : monitorTerminals)
                {
                    if (monitor == node) { role = "monitor"; break; }
                }
                deviceProfiler.RegisterDevice(node->GetId(), (*it)->GetIfIndex(), ap, rat, role);
            }
        };
        registerDevices(m_nrGnbDevs, 1, "nr");
        registerDevices(m_nrUeDevs, 1, "nr");
        for (uint32_t ap = 1; ap < wifiDevices.size(); ++ap)
        {
            registerDevices(wifiDevices[ap], ap + 1, "wifi");
        }
        for (uint32_t i = 0; i < terms.size() && i < m_termAccessState.size(); ++i)
        {
            deviceProfiler.SelectAp(terms[i]->GetId(), m_termAccessState[i].currentAp);
        }
    }

    // Keep per-cycle FlowMonitor diagnostics scoped to this simulation run.
    if (kEnableFlowOutputLogs)
    {
        const std::string flowCsvPath = std::string(m_outputDir) + "flow_per_cycle.csv";
        std::ofstream resetFlowCsv(flowCsvPath, std::ios::trunc);
        if (!resetFlowCsv.good())
        {
            NS_LOG_WARN("Failed to reset flow diagnostics CSV: " << flowCsvPath);
        }

        const std::string browserCsvPath = std::string(m_outputDir) + "browser_send_events.csv";
        std::ofstream resetBrowserCsv(browserCsvPath, std::ios::trunc);
        if (!resetBrowserCsv.good())
        {
            NS_LOG_WARN("Failed to reset browser send diagnostics CSV: " << browserCsvPath);
        }
    }

    FlowMonitorHelper flowmonHelper;
    NodeContainer terminalMonitorNodes;
    for (const auto& term : terms)
    {
        if (term != nullptr)
        {
            terminalMonitorNodes.Add(term);
        }
    }
    if (server_browser != nullptr)
    {
        terminalMonitorNodes.Add(server_browser);
    }
    if (server_udpVideo != nullptr)
    {
        terminalMonitorNodes.Add(server_udpVideo);
    }
    Ptr<FlowMonitor> flowMonitor;
    {
        ResearchWallProfiler::Scope timer("FlowMonitorHelper::Install");
        flowMonitor = flowmonHelper.Install(terminalMonitorNodes);
    }
    Ptr<Ipv4FlowClassifier> flowClassifier = DynamicCast<Ipv4FlowClassifier>(flowmonHelper.GetClassifier());

    // 端末別TP計測用にFlowMonitor/Classifierを保持
    m_termFlowMonitor = flowMonitor;
    m_termFlowClassifier = flowClassifier;
    BuildTerminalIpMap();

    SetAppLayer(); // 各種アプリケーションの設定
    if (m_marlRttTrace) StartMarlRttTrace();
    if (m_queueDiagnostics)
    {
        StartQueueDiagnostics();
    }

    if (m_simulationDuration.IsPositive())
    {
        Simulator::Stop(m_simulationDuration);
    }

    Time checkStop = m_simulationDuration.IsZero() ? Seconds(7.0) : m_simulationDuration;
    if (kEnableFlowOutputLogs && flowMonitor && checkStop.IsPositive())
    {
        Time checkTime = checkStop - MilliSeconds(1);
        if (checkTime.IsNegative())
        {
            checkTime = checkStop;
        }
        Simulator::Schedule(checkTime, &NetSim::CheckFlowMonitor, this, flowMonitor, flowClassifier);
    }

    std::cout << "=====Simulator::Start()=====" << std::endl;
    auto& profiler = ResearchWallProfiler::Get();
    if (profiler.Enabled())
    {
        profiler.Boundary("run_start", 0, Simulator::Now().GetSeconds(), Simulator::GetEventCount());
    }
    {
        ResearchWallProfiler::Scope timer("Simulator::Run");
        Simulator::Run();
    }
    FinishCapacitySchedule();
    FinishAp0CapacityExperiment();
    FinishAp2CapacityExperiment();
    m_ap1SampleEvent.Cancel();
    if (m_ap1Samples.is_open())
    {
        SampleAp1Capacity();
        m_ap1SampleEvent.Cancel();
        m_ap1Samples.close();
        m_ap1Events.close();
    }
    if (m_queueDiagnostics)
    {
        m_queueSampleEvent.Cancel();
        SampleQueueDiagnostics(); // Preserve counters at the exact stop time.
        m_queueSampleEvent.Cancel();
        m_queueCsv.close();
        m_linkLoadCsv.close();
    }
    if (profiler.Enabled())
    {
        profiler.Boundary("run_end", 0, Simulator::Now().GetSeconds(), Simulator::GetEventCount());
    }
    {
        ResearchWallProfiler::Scope timer("Simulator::Destroy");
        Simulator::Destroy();
    }
    profiler.Snapshot("after_destroy", 0);
    std::cout << "=====Simulator::End()=====" << std::endl;
}

void NetSim::CheckFlowMonitor(Ptr<FlowMonitor> monitor, Ptr<Ipv4FlowClassifier> classifier)
{
    NS_LOG_FUNCTION(this);

    if (monitor == nullptr)
    {
        NS_LOG_WARN("FlowMonitor instance is null");
        return;
    }

    if (!kEnableFlowOutputLogs)
    {
        return;
    }

    monitor->CheckForLostPackets();

    const std::string throughputFile = std::string(m_outputDir) + "monitor-flow-throughput.csv";
    bool writeHeader = false;
    {
        std::ifstream check(throughputFile);
        if (!check.good() || check.peek() == std::ifstream::traits_type::eof())
        {
            writeHeader = true;
        }
    }
    std::ofstream throughputStream(throughputFile, std::ios::app);
    if (throughputStream.good())
    {
        if (writeHeader)
        {
            throughputStream << "time_s,flow_id,src,dst,protocol,src_port,dst_port,rx_bytes,tx_packets,rx_packets,throughput_bps\n";
        }

        if (classifier)
        {
            const auto stats = monitor->GetFlowStats();
            auto isStationWifiAddress = [this](const Ipv4Address& addr) {
                return m_wifiStationAddresses.find(addr.Get()) != m_wifiStationAddresses.end();
            };
            for (const auto& entry : stats)
            {
                FlowId flowId = entry.first;
                const FlowMonitor::FlowStats& stat = entry.second;
                if (stat.rxPackets == 0 || stat.timeLastRxPacket <= stat.timeFirstTxPacket)
                {
                    continue;
                }

                double duration = (stat.timeLastRxPacket - stat.timeFirstTxPacket).GetSeconds();
                if (duration <= 0.0)
                {
                    continue;
                }

                double throughputBps = static_cast<double>(stat.rxBytes) * 8.0 / duration;
                Ipv4FlowClassifier::FiveTuple tuple = classifier->FindFlow(flowId);
                bool srcIsSta = isStationWifiAddress(tuple.sourceAddress);
                bool dstIsSta = isStationWifiAddress(tuple.destinationAddress);
                if (!(srcIsSta || dstIsSta))
                {
                    continue;
                }

                throughputStream << Simulator::Now().GetSeconds() << ","
                                 << flowId << ","
                                 << tuple.sourceAddress << ","
                                 << tuple.destinationAddress << ","
                                 << static_cast<uint32_t>(tuple.protocol) << ","
                                 << tuple.sourcePort << ","
                                 << tuple.destinationPort << ","
                                 << stat.rxBytes << ","
                                 << stat.txPackets << ","
                                 << stat.rxPackets << ","
                                 << throughputBps << "\n";
            }
        }
        else
        {
            NS_LOG_WARN("Flow classifier is null; throughput CSV not written.");
        }
    }
    else
    {
        NS_LOG_WARN("Failed to open throughput file: " << throughputFile);
    }

    std::ostringstream filename;
    filename << m_outputDir << "monitor-flow";
    filename << "_" << m_assignmentMethod;
    filename << ".xml";

    monitor->SerializeToXmlFile(filename.str(), true, true);
}

}   // namespace ns3
